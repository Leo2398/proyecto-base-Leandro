import 'package:flutter/material.dart';

import '../models/order_detail_model.dart';
import '../models/order_model.dart';
import '../services/interfaces/i_order_service.dart';
import '../services/order_service.dart';

class OrderController extends ChangeNotifier {
  final IOrderService _orderService;

  OrderController({IOrderService? orderService})
      : _orderService = orderService ?? OrderService();

  List<OrderModel> _clientOrders = [];
  List<OrderModel> _producerOrders = [];
  List<OrderDetailModel> _orderDetails = [];

  bool _isLoading = false;
  bool _isCreating = false;
  bool _isLoadingDetails = false;
  bool _isUpdatingState = false;

  String? _errorMessage;
  String? _successMessage;

  int? _lastCreatedOrderId;

  List<OrderModel> get clientOrders => List.unmodifiable(_clientOrders);
  List<OrderModel> get producerOrders => List.unmodifiable(_producerOrders);
  List<OrderDetailModel> get orderDetails => List.unmodifiable(_orderDetails);

  bool get isLoading => _isLoading;
  bool get isCreating => _isCreating;
  bool get isLoadingDetails => _isLoadingDetails;
  bool get isUpdatingState => _isUpdatingState;

  String? get errorMessage => _errorMessage;
  String? get successMessage => _successMessage;

  int? get lastCreatedOrderId => _lastCreatedOrderId;

  bool get hasClientOrders => _clientOrders.isNotEmpty;
  bool get hasProducerOrders => _producerOrders.isNotEmpty;
  bool get hasOrderDetails => _orderDetails.isNotEmpty;

  void clearMessages() {
    _errorMessage = null;
    _successMessage = null;
    notifyListeners();
  }

  void clearOrderDetails() {
    _orderDetails = [];
    notifyListeners();
  }

  void clearClientOrders() {
    _clientOrders = [];
    notifyListeners();
  }

  void clearProducerOrders() {
    _producerOrders = [];
    notifyListeners();
  }

  void clearAll() {
    _clientOrders = [];
    _producerOrders = [];
    _orderDetails = [];
    _isLoading = false;
    _isCreating = false;
    _isLoadingDetails = false;
    _isUpdatingState = false;
    _errorMessage = null;
    _successMessage = null;
    _lastCreatedOrderId = null;
    notifyListeners();
  }

  Future<int?> createOrder(
      OrderModel order,
      List<OrderDetailModel> details,
      ) async {
    try {
      _isCreating = true;
      _errorMessage = null;
      _successMessage = null;
      _lastCreatedOrderId = null;
      notifyListeners();

      if (details.isEmpty) {
        _errorMessage = 'El pedido no tiene productos.';
        return null;
      }

      if (order.clientID <= 0) {
        _errorMessage = 'Cliente inválido.';
        return null;
      }

      if (order.producerID <= 0) {
        _errorMessage = 'Productor inválido.';
        return null;
      }

      if (order.pickupLocationID <= 0) {
        _errorMessage = 'Ubicación de entrega inválida.';
        return null;
      }

      if (order.amount <= 0) {
        _errorMessage = 'El monto del pedido debe ser mayor a 0.';
        return null;
      }

      final createdOrderId = await _orderService.createOrder(order, details);

      if (createdOrderId == null || createdOrderId <= 0) {
        _errorMessage = 'No se pudo registrar el pedido.';
        return null;
      }

      _lastCreatedOrderId = createdOrderId;
      _successMessage = 'Pedido registrado correctamente.';

      await loadOrdersByClient(order.clientID);

      return createdOrderId;
    } catch (e) {
      _errorMessage = 'Error al crear pedido: $e';
      return null;
    } finally {
      _isCreating = false;
      notifyListeners();
    }
  }

  Future<void> loadOrdersByClient(int clientID) async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      if (clientID <= 0) {
        _errorMessage = 'ID de cliente inválido.';
        _clientOrders = [];
        return;
      }

      _clientOrders = await _orderService.getOrdersByClient(clientID);
    } catch (e) {
      _errorMessage = 'Error cargando pedidos del cliente: $e';
      _clientOrders = [];
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadOrdersByProducer(int producerID) async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      if (producerID <= 0) {
        _errorMessage = 'ID de productor inválido.';
        _producerOrders = [];
        return;
      }

      _producerOrders = await _orderService.getOrdersByProducer(producerID);
    } catch (e) {
      _errorMessage = 'Error cargando pedidos del productor: $e';
      _producerOrders = [];
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadOrderDetails(int orderID) async {
    try {
      _isLoadingDetails = true;
      _errorMessage = null;
      notifyListeners();

      if (orderID <= 0) {
        _errorMessage = 'ID de pedido inválido.';
        _orderDetails = [];
        return;
      }

      _orderDetails = await _orderService.getOrderDetails(orderID);
    } catch (e) {
      _errorMessage = 'Error cargando detalle del pedido: $e';
      _orderDetails = [];
    } finally {
      _isLoadingDetails = false;
      notifyListeners();
    }
  }

  Future<bool> updateOrderState(int orderID, int state) async {
    try {
      _isUpdatingState = true;
      _errorMessage = null;
      _successMessage = null;
      notifyListeners();

      if (orderID <= 0) {
        _errorMessage = 'ID de pedido inválido.';
        return false;
      }

      if (state < 0) {
        _errorMessage = 'Estado de pedido inválido.';
        return false;
      }

      final success = await _orderService.updateOrderState(orderID, state);

      if (!success) {
        _errorMessage = 'No se pudo actualizar el estado del pedido.';
        return false;
      }

      _clientOrders = _clientOrders
          .map(
            (order) => order.id == orderID ? order.copyWith(state: state) : order,
      )
          .toList();

      _producerOrders = _producerOrders
          .map(
            (order) => order.id == orderID ? order.copyWith(state: state) : order,
      )
          .toList();

      _successMessage = 'Estado del pedido actualizado correctamente.';
      return true;
    } catch (e) {
      _errorMessage = 'Error actualizando estado del pedido: $e';
      return false;
    } finally {
      _isUpdatingState = false;
      notifyListeners();
    }
  }
}